package no.uio.ifi.in2000.viljardh.vitseapplive.model.jokes

data class Jokes(
    val jokes: List<Joke>
)
